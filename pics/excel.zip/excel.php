 <?php include_once('config.php');?>
<!DOCTYPE html>
<html lang="pt-br">
	<head><meta charset="utf-8">
	<title>Cadastro de Clientes</title>
	<head>
	<body>
		<?php
		$datahoje = date('d-m-Y-s');
		$arquivo = 'clientes'.$datahoje.'.xls';
		$html = '';
		$html .= '<table border="1">';
		$html .= '<tr>';
		$html .= '<td colspan="3"><center><b>Cadastro de Clientes</b></center></td>';
		$html .= '</tr>';
		$html .= '<tr>';
		$html .= '<td><b>NOME</b></td>';
		$html .= '<td><b>CELULAR</b></td>';
		$html .= '<td><b>CPF</b></td>';
		$html .= '</tr>';
	$conn = mysqli_connect($servidor, $dbusuario, $dbsenha, $dbname);
	mysqli_set_charset($conn,"utf8");	
	$result_sql = "SELECT * FROM tbclientes Order By nome ASC";
	$result_query = mysqli_query($conn, $result_sql);
	while($linha = mysqli_fetch_assoc($result_query)){
		$html .= '<tr>';
		$html .= '<td>'.$linha["nome"].'</td>';
		$html .= '<td>'.$linha["celular"].'</td>';
		$html .= '<td>'.$linha["cpf"].'</td>';
	    $html .= '</tr>';
			;
		}
		//download
		header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
		header ("Cache-Control: no-cache, must-revalidate");
		header ("Pragma: no-cache");
		header ("Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		header('Content-Transfer-Encoding: binary');
		header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
		header ("Content-Description: PHP Generated Data" );
		// Envia o download
		echo $html;
		exit; ?>
	</body>
</html>