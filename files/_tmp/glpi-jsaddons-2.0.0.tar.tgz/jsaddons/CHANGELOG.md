# JS Addons GLPI Plugin CHANGELOG
## 2.0.0 - 2022-07-27
### Features
- GLPI 10 Compatibility #10338

## 1.0.0
### Features
Analytics:
* Metricool
* Google Analytics

Chat:
* Tawk.to